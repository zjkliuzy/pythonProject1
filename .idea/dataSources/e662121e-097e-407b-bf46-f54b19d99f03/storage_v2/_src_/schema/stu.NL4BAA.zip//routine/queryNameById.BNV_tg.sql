create
    definer = root@`%` function queryNameById(uid int) returns varchar(20)
begin
return  (select name from class_1 where id=uid);
end;

