create
    definer = root@`%` function calculateScoreDiff(uid1 int, uid2 int) returns int
begin
	declare a int;
	declare b int;
	set a = (select score from class_1 where id = uid1);
	set b =(select score from class_1 where id = uid2);
return a-b;
end;

