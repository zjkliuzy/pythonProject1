create
    definer = root@`%` procedure test1(IN name1 varchar(20))
begin
	SELECT * from class_1 where name = name1;
	insert into hobby(name,phone,hobby) values (name1,56565665556,"football"); 
end;

