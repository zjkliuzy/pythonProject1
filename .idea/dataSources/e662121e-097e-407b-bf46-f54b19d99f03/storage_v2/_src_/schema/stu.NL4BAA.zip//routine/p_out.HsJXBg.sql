create
    definer = root@`%` procedure p_out(OUT num int)
begin
	SELECT num;
	set num =100;
	SELECT num;
end;

